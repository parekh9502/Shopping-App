//
//  AddToCartTableViewCell.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 12/15/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//
import UIKit

class AddToCartTableViewCell: UITableViewCell {


    @IBOutlet weak var txtTotal: UILabel!
    @IBOutlet weak var txtItemPrice: UILabel!
    @IBOutlet weak var txtQuantity: UILabel!
    @IBOutlet weak var txtProductName: UILabel!
    @IBOutlet weak var imageVWProduct: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
   
}
