//
//  AddToCartTableViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 12/15/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import  CoreData
import SDWebImage
import TWMessageBarManager

class AddToCartTableViewController: UITableViewController, NSFetchedResultsControllerDelegate,PayPalPaymentDelegate {
    
    var environment:String = PayPalEnvironmentNoNetwork {
        willSet(newEnvironment) {
            if (newEnvironment != environment) {
                PayPalMobile.preconnect(withEnvironment: newEnvironment)
            }
        }
    }
    var payPalConfig = PayPalConfiguration() // default
    
    var webservices = Webservices()
    var ad = UIApplication.shared.delegate as! AppDelegate
    @IBOutlet weak var txtTotal: UILabel!
    var frc: NSFetchedResultsController<Cart>?
    let utility = Utility()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        payPalConfig.acceptCreditCards = false
        payPalConfig.merchantName = "BuyHere.Com"
        payPalConfig.merchantPrivacyPolicyURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/privacy-full")
        payPalConfig.merchantUserAgreementURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/useragreement-full")
        payPalConfig.languageOrLocale = Locale.preferredLanguages[0]
        payPalConfig.payPalShippingAddressOption = .both;
        
        
        let context = self.ad.persistentContainer.viewContext
        let fetchrequest = NSFetchRequest<Cart>(entityName: "Cart")
        print("Batch size",fetchrequest.fetchBatchSize)
        fetchrequest.sortDescriptors = [NSSortDescriptor(key:"id",ascending:true)]
        self.frc = NSFetchedResultsController<Cart>(fetchRequest: fetchrequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        self.frc?.delegate = self as! NSFetchedResultsControllerDelegate
        do {
            try self.frc?.performFetch()
        } catch  {
            fatalError("failed to fetch entities \(error)")
        }
        var totalprice=0;
        let objects = frc?.fetchedObjects
        for object in objects!{
           totalprice = totalprice+(Int(object.price!)!*Int(object.quantity!)!)
        }
        txtTotal.text="\(totalprice/64)"
        self.tableView.reloadData()
        let tabItems = self.tabBarController?.tabBar.items as NSArray!
        
        // In this case we want to modify the badge number of the third tab:
        let tabItem = tabItems?[2] as! UITabBarItem
        
        // Now set the badge of the third tab
        tabItem.badgeValue = "\(Int((objects?.count)!))"
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        var totalprice=0;
        let objects = frc?.fetchedObjects
        for object in objects!{
            totalprice = totalprice+(Int(object.price!)!*Int(object.quantity!)!)
        }
        txtTotal.text="\(totalprice/64)"
        self.tableView.reloadData()
        PayPalMobile.preconnect(withEnvironment: environment)
        let tabItems = self.tabBarController?.tabBar.items as NSArray!
         let tabItem = tabItems?[2] as! UITabBarItem
         tabItem.badgeValue = "\(Int((objects?.count)!))"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        if utility.entityIsEmpty(entity: "Cart"){
            return 1
        }else{
            return frc!.sections!.count
        }

    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        guard let sections = self.frc?.sections else {
            fatalError("No sections in fetchedResultsController")
        }
        let sectionInfo = sections[section]
        
        return sectionInfo.numberOfObjects
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddToCartTableViewCell", for: indexPath) as! AddToCartTableViewCell

        // Configure the cell...
        guard let object = self.frc?.object(at: indexPath) else {
            fatalError("Attempt to configure cell without a managed object")
        }
       cell.txtProductName.text = object.productName
        cell.txtQuantity.text = "Qty:"+object.quantity!
        cell.txtItemPrice.text = "$\(Int(object.price!)!/64)"
        cell.imageVWProduct.sd_setImage(with: URL(string:object.image!))
        utility.downloadImage(url: URL(string:object.image!)!)
        cell.txtTotal.text = "Subtotal: $\(Int((object.quantity)!)!*Int((object.price)!)!/64)"
       
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let object = self.frc?.object(at: indexPath) else {
            fatalError("Attempt to configure cell without a managed object")
        }
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        let VC1 = storyBoard.instantiateViewController(withIdentifier: "EditCartItemViewController") as! EditCartItemViewController
        
        VC1.cartItem = object
        self.navigationController?.pushViewController(VC1, animated: true)
        

    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            guard let object = self.frc?.object(at: indexPath) else {
                fatalError("Attempt to configure cell without a managed object")
            }
            ad.persistentContainer.viewContext.delete(object as! NSManagedObject)
            ad.saveContext()
            let objects = frc?.fetchedObjects
            let tabItems = self.tabBarController?.tabBar.items as NSArray!
            let tabItem = tabItems?[2] as! UITabBarItem
            tabItem.badgeValue = "\(Int((objects?.count)!))"
            
            
            tableView.reloadData()
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>){
        tableView.beginUpdates()
    }
    
    
    /* Notifies the delegate that all section and object changes have been sent. Enables NSFetchedResultsController change tracking.
     Clients may prepare for a batch of updates by using this method to begin an update block for their view.
     Providing an empty implementation will enable change tracking if you do not care about the individual callbacks.
     */
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>){
        tableView.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?){
        switch type {
        case .insert:
            
            tableView.insertRows(at: [newIndexPath!], with: UITableViewRowAnimation.fade)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: UITableViewRowAnimation.fade)
        case .update:
            tableView.reloadData()
        default:
            print("")
        }
    }
    
    @IBAction func btnConfirmOrder(_ sender: Any) {
        let total = NSDecimalNumber(string:txtTotal.text)
        
        let payment = PayPalPayment(amount: total, currencyCode: "USD", shortDescription: "BuyHere.Com", intent: .sale)
        
        // payment.items = items
        //  payment.paymentDetails = paymentDetails
        
        if (payment.processable) {
            let paymentViewController = PayPalPaymentViewController(payment: payment, configuration: payPalConfig, delegate: self)
            present(paymentViewController!, animated: true, completion: nil)
        }
        else {
            // This particular payment will always be processable. If, for
            // example, the amount was negative or the shortDescription was
            // empty, this payment wouldn't be processable, and you'd want
            // to handle that here.
            print("Payment not processalbe: \(payment)")
        }
    }
   
    
    func payPalPaymentDidCancel(_ paymentViewController: PayPalPaymentViewController) {
        print("PayPal Payment Cancelled")
        //  resultText = ""
        //  successView.isHidden = true
        paymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalPaymentViewController(_ paymentViewController: PayPalPaymentViewController, didComplete completedPayment: PayPalPayment) {
        print("PayPal Payment Success !")
        paymentViewController.dismiss(animated: true, completion: { () -> Void in
            // send completed confirmaion to your server
            print("Here is your proof of payment:\n\n\(completedPayment.confirmation)\n\nSend this to your server for confirmation and fulfillment.")
            let mobilenumber = UserDefaults.standard.string(forKey: "userphone")
            let webservice = Webservices()
            let objects = self.frc?.fetchedObjects
            for object in objects!{
                webservice.orderItem(itemID: (object.id)!, itemName: (object.productName)!, quantity: object.quantity!, finalPrice:"\((Int(object.price!)!*Int(object.quantity!)!))" , mobileNumber: mobilenumber!, completion: { (msg) in
                    let message = msg as! String
                    TWMessageBarManager.sharedInstance().showMessage(withTitle: "Order", description: message, type: .info)
                   
                })
            }
            
            
            
            
            
            //        self.resultText = completedPayment.description
            //        self.showSuccess()
        })
    }
    
}
