//
//  CatagoryTableViewCell.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/29/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//
import UIKit

class CatagoryTableViewCell: UITableViewCell {

    @IBOutlet weak var txtCatagoryName: UILabel!
    @IBOutlet weak var txtDescription: UILabel!
    @IBOutlet weak var imageVwCatagory: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
