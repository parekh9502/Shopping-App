//
//  EditCartItemViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 12/28/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import CoreData
import SCLAlertView

class EditCartItemViewController: UIViewController {
    var cartItem:Cart?
    var ad = UIApplication.shared.delegate as! AppDelegate
    var utility = Utility()
    
    @IBOutlet weak var txtQuantity: UILabel!
    @IBOutlet weak var txtUnitPrize: UILabel!
    @IBOutlet weak var txtTotalPrize: UILabel!
    @IBOutlet weak var txtProductName: UILabel!
    @IBOutlet weak var imageViewProduct: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if cartItem != nil{
            txtQuantity.text = cartItem?.quantity
            txtUnitPrize.text = "$\(Int((cartItem?.price)!)!/64)"
            
            txtProductName.text = (cartItem?.productName)!
            do {
                imageViewProduct.image = try utility.showImageFromDocumentDirectory(imageName: (cartItem?.image?.fileName())!)
            } catch  {
                print("Image Unavialable")
            }
            txtTotalPrize.text = "\(Int((cartItem?.quantity)!)!*Int((cartItem?.price)!)!/64)"
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func cancelChangeAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnIncreaseQty(_ sender: Any) {
       
        var qty = Int(txtQuantity.text!)!
       // if qty < Int((cartItem?.quantity)!)!{
            qty = qty+1
            txtQuantity.text = "\(String(describing: qty))"
            let totalPrice = Int((txtUnitPrize.text?.replacingOccurrences(of: "$", with: ""))!)!*qty
            txtTotalPrize.text = "\(totalPrice)"
      //  }else{
       //     SCLAlertView().showInfo("Order Error", subTitle: "Sorry we are short on this product")
      //  }
        
    }
   
    @IBAction func btnSavetoCart(_ sender: Any) {
        cartItem?.quantity = txtQuantity.text!
        ad.saveContext()
    }
    
    @IBAction func btnDecreaseQty(_ sender: Any) {
        
        var qty = Int(txtQuantity.text!)!
        if qty != 0{
            qty = qty-1
            txtQuantity.text = "\(qty)"
            let totalPrice = Int((txtUnitPrize.text?.replacingOccurrences(of: "$", with: ""))!)!*qty
            txtTotalPrize.text = "\(totalPrice)"
        }else if(qty == 0){
            txtTotalPrize.text = "\(0)"
        }
    }
}
