

import UIKit


class FTSurvivalDetail: UIView {
    @IBOutlet weak var labelCategoryTitle: UILabel!
    @IBOutlet weak var labelGuideTitle: UILabel!
    @IBOutlet weak var imageBackgroundView: UIImageView!
    @IBOutlet weak var imageForgroundView: UIImageView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var webViewDes: UIWebView!
    
    let imageTranslate: CGFloat = -200.0
    let viewTranslate: CGFloat = 150.0
    let diffTranslate: CGFloat = -100.0
    let diffBottomTranslate: CGFloat = -150.0
    
    @IBOutlet weak var btnBuy: UIButton!
    
    @IBOutlet weak var btnAddtoCart: UIButton!
    
    //MARK: - Public Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.clear
    }
    
    var viewScrollNormalised: CGFloat = 0.0 {
        didSet {
            if oldValue != viewScrollNormalised {
                self.handleScroll(forNormalise: viewScrollNormalised)
            }
        }
    }
    @IBAction func btnBack(_ sender: Any) {
    }
    
    fileprivate func handleScroll (forNormalise normalise: CGFloat) {
        self.labelCategoryTitle.transform = CGAffineTransform(translationX: normalise * self.diffTranslate, y: 0)
        self.labelGuideTitle.transform = CGAffineTransform(translationX: normalise * self.diffBottomTranslate, y: 0)
        self.webViewDes.transform = CGAffineTransform(translationX: normalise * self.diffBottomTranslate, y: 0)
        self.imageBackgroundView.transform = CGAffineTransform(translationX: normalise * self.imageTranslate, y: 0)
    }

}
