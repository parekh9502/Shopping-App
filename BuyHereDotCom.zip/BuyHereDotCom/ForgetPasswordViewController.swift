//
//  ForgetPasswordViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/25/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import  SCLAlertView
import TWMessageBarManager
class ForgetPasswordViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var txtMobile: UITextField!
    
    @IBAction func forgotAction(_ sender: Any) {
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/shop_fogot_pass.php?&mobile=\(txtMobile.text!)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            print(response)
            print(error)
            if error == nil{
                guard let returnData = String(data: data!, encoding: .utf8) else{
                    return
                }
                print(returnData)
                
                if let range = returnData.range(of: "UserPassword") {
                    var password = returnData.substring(from: range.upperBound)
                    print("password ",password)
                    password = password.replacingOccurrences(of: "[ } | \" ]", with: "", options: [.regularExpression])
                    DispatchQueue.main.async {
                        SCLAlertView().showInfo("Requested info", subTitle: "Your password is\(password.replacingOccurrences(of: "]", with: ""))")
                    }
                }
                // TWMessageBarManager.sharedInstance().showMessage(withTitle:"We want you to know" , description: returnData, type: .success)
                
                
                
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
