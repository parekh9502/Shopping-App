//
//  Model.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 12/05/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//


import Foundation
struct ProductModel{
    var id:String
    var name:String
    var image:String
    var quantity:String
    var description:String
    var prize:String
}

struct OrderHistory{
    var id:String
    var name:String
    var quantity:String
    var status:String
    var price:String
}

