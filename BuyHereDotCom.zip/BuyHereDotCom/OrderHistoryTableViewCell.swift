//
//  OrderHistoryTableViewCell.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 12/15/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit

class OrderHistoryTableViewCell: UITableViewCell {
    @IBOutlet weak var txtOrderStatus: UILabel!
    @IBOutlet weak var viewTopColor: UIView!
    @IBOutlet weak var txtOrderID: UILabel!
    @IBOutlet weak var txtProductName: UILabel!
    @IBOutlet weak var txtQuantity: UILabel!
    @IBOutlet weak var txtPrice: UILabel!
    @IBOutlet weak var ImageViewOrderStatus: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
