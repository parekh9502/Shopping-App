//
//  OrderViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 12/15/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import  SCLAlertView

class OrderViewController: UIViewController,PayPalPaymentDelegate {

    //http://rjtmobile.com/ansari/shopingcart/androidapp/orders.php?&item_id=701&item_names=laptop&item_quantity=1&final_price=100000&mobile=654987
    
    var environment:String = PayPalEnvironmentNoNetwork {
        willSet(newEnvironment) {
            if (newEnvironment != environment) {
                PayPalMobile.preconnect(withEnvironment: newEnvironment)
            }
        }
    }
    var payPalConfig = PayPalConfiguration() // default
    var productToBuy: ProductModel?
    var utility = Utility()
    
    
    @IBOutlet weak var txtQuantity: UILabel!
    @IBOutlet weak var txtUnitPrize: UILabel!
    @IBOutlet weak var txtTotalPrize: UILabel!
    @IBOutlet weak var txtProductName: UILabel!
    @IBOutlet weak var imageViewProduct: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        payPalConfig.acceptCreditCards = false
        payPalConfig.merchantName = "BuyHere.Com"
        payPalConfig.merchantPrivacyPolicyURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/privacy-full")
        payPalConfig.merchantUserAgreementURL = URL(string: "https://www.paypal.com/webapps/mpp/ua/useragreement-full")
        payPalConfig.languageOrLocale = Locale.preferredLanguages[0]
        payPalConfig.payPalShippingAddressOption = .both;
        
        if productToBuy != nil{
            txtQuantity.text = "0"
            txtUnitPrize.text = "$\(Int((productToBuy?.prize)!)!/64)"
            
            txtProductName.text = (productToBuy?.name)!
            do {
                 imageViewProduct.image = try utility.showImageFromDocumentDirectory(imageName: (productToBuy?.image.fileName())!)
            } catch  {
                print("Image Unavialable")
            }
            txtTotalPrize.text = "0"
            
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        PayPalMobile.preconnect(withEnvironment: environment)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btnCancelOrder(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnConfirmOrder(_ sender: Any) {
        let total = NSDecimalNumber(string:txtTotalPrize.text)
        
        let payment = PayPalPayment(amount: total, currencyCode: "USD", shortDescription: "BuyHere.Com", intent: .sale)
        
       // payment.items = items
      //  payment.paymentDetails = paymentDetails
        
        if (payment.processable) {
            let paymentViewController = PayPalPaymentViewController(payment: payment, configuration: payPalConfig, delegate: self)
            present(paymentViewController!, animated: true, completion: nil)
        }
        else {
            // This particular payment will always be processable. If, for
            // example, the amount was negative or the shortDescription was
            // empty, this payment wouldn't be processable, and you'd want
            // to handle that here.
            print("Payment not processalbe: \(payment)")
        }
        
    }
    @IBAction func btnIncreaseQty(_ sender: Any) {
        
        var qty = Int(txtQuantity.text!)!
        if qty < Int((productToBuy?.quantity)!)!{
            qty = qty+1
            txtQuantity.text = "\(String(describing: qty))"
            let totalPrice = Int((txtUnitPrize.text?.replacingOccurrences(of: "$", with: ""))!)!*qty
            txtTotalPrize.text = "\(totalPrice)"
        }else{
            SCLAlertView().showInfo("Order Error", subTitle: "Sorry we are short on this product")
        }
        
    }

    @IBAction func btnDecreaseQty(_ sender: Any) {
        
        var qty = Int(txtQuantity.text!)!
        if qty != 0{
            qty = qty-1
            txtQuantity.text = "\(qty)"
            let totalPrice = Int((txtUnitPrize.text?.replacingOccurrences(of: "$", with: ""))!)!*qty
            txtTotalPrize.text = "\(totalPrice)"
        }else if(qty == 0){
           txtTotalPrize.text = "\(0)"
        }
    }
    
    func payPalPaymentDidCancel(_ paymentViewController: PayPalPaymentViewController) {
        print("PayPal Payment Cancelled")
      //  resultText = ""
      //  successView.isHidden = true
        paymentViewController.dismiss(animated: true, completion: nil)
    }
    
    func payPalPaymentViewController(_ paymentViewController: PayPalPaymentViewController, didComplete completedPayment: PayPalPayment) {
        print("PayPal Payment Success !")
        paymentViewController.dismiss(animated: true, completion: { () -> Void in
            // send completed confirmaion to your server
            print("Here is your proof of payment:\n\n\(completedPayment.confirmation)\n\nSend this to your server for confirmation and fulfillment.")
            let mobilenumber = UserDefaults.standard.string(forKey: "userphone")
            let webservice = Webservices()
            webservice.orderItem(itemID: (self.productToBuy?.id)!, itemName: (self.productToBuy?.name)!, quantity: self.txtQuantity.text!, finalPrice: self.txtTotalPrize.text!, mobileNumber: mobilenumber!, completion: { (msg) in
                let message = msg as! String
                SCLAlertView().showInfo("Order", subTitle: message)
            })
            
            
    //        self.resultText = completedPayment.description
    //        self.showSuccess()
        })
    }
}
