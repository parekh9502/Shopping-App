//
//  ProductsViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/29/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import TAPageControl
import  SwipeView
import CoreData
import TWMessageBarManager
class ProductsViewController: BaseViewController {
    
    
    var ad = UIApplication.shared.delegate as! AppDelegate
    var frc: NSFetchedResultsController<Product>?
    let utility = Utility()
    var productModelArray:[ProductModel] = []
    
    @IBOutlet weak var swipeView: SwipeView!
    @IBOutlet weak var taPageControl: TAPageControl!
    var subCatagoryID: String?
    var webservices = Webservices()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        deleteAllRecords()
        apiCall()
       // print(subCatagoryID)
       

    }
    func apiCall()  {
        webservices.setProduct(id: subCatagoryID!) { (msg) in
            if let message = msg as? String{
                print(message)
                let context = self.ad.persistentContainer.viewContext
                let fetchrequest = NSFetchRequest<Product>(entityName: "Product")
                print("Batch size",fetchrequest.fetchBatchSize)
                fetchrequest.sortDescriptors = [NSSortDescriptor(key:"id",ascending:true)]
                self.frc = NSFetchedResultsController<Product>(fetchRequest: fetchrequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
                //   self.frc?.delegate = self as! NSFetchedResultsControllerDelegate
                do {
                    try self.frc?.performFetch()
                } catch  {
                    fatalError("failed to fetch entities \(error)")
                }
                //self.tableView.reloadData()
                guard let objects = self.frc?.fetchedObjects else {
                    fatalError("Attempt to configure cell without a managed object")
                }
                for object in objects{
                    let productModel = ProductModel(id: object.id!, name: object.productName!, image: object.productImage!, quantity: object.quantity!, description: object.productDescription!, prize: object.prize!)
                    self.productModelArray.append(productModel)
                    
                }
                DispatchQueue.main.async {
                    print("Objects Count",objects.count)
                    
                    self.taPageControl.numberOfPages = objects.count
                    self.taPageControl.currentPage = 0
                    self.taPageControl.dotImage = UIImage(named: "pageControlUnselected")
                    self.taPageControl.currentDotImage = UIImage(named: "pageControlSelected")
                    self.swipeView.reloadData()
                }
               
                
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func deleteAllRecords() {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let context = delegate.persistentContainer.viewContext
        
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
        } catch {
            print ("There was an error")
        }
    }
}


extension ProductsViewController: SwipeViewDataSource, SwipeViewDelegate, UIScrollViewDelegate {
    
    func numberOfItems(in swipeView: SwipeView!) -> Int {
        return productModelArray.count
    }
    
    func swipeView(_ swipeView: SwipeView!, viewForItemAt index: Int, reusing view: UIView!) -> UIView! {
        
        var currentView = view as? FTSurvivalDetail
        if (currentView == nil) {
            let views: [Any] = Bundle.main.loadNibNamed("FTSurvivalDetail", owner: nil, options: nil)!
            currentView = views.first as? FTSurvivalDetail
        }
        /*let indexPath = IndexPath(row: index, section: 0)
        guard let object = self.frc?.object(at: indexPath) else {
            fatalError("Attempt to configure cell without a managed object")
        }
        */
           // print("Prod Name",object.productName)
            currentView?.labelCategoryTitle.text = productModelArray[index].name
       // print("\(String(describing:Int(productModelArray[index].prize)!/64))")
        
        let priceofProduct = Int(productModelArray[index].prize)!/64
        if (priceofProduct as? Int) != nil {
            currentView?.labelGuideTitle.text = " Price $" + "\(Int(self.productModelArray[index].prize)!/64)" + "   Available: \(String(describing:self.productModelArray[index].quantity))"
            
        }
        
        do {
           currentView?.imageBackgroundView.image = try utility.showImageFromDocumentDirectory(imageName: productModelArray[index].image.fileName())
        } catch  {
            print("Error")
        }
        
        
            currentView?.btnBack.addTarget(self,action:#selector(buttonClicked(sender:)), for: .touchUpInside)
            currentView!.frame = swipeView.bounds
            currentView?.clipsToBounds = true
        //webView.loadHTMLString("<html><body><p>Hello!</p></body></html>", baseURL: nil)
        currentView?.webViewDes.loadHTMLString("<html><body><p>\(productModelArray[index].description)</p></body></html>", baseURL: nil)
        
        // cell.likebutton.addTarget(self, action: #selector(NewsFeedTableViewController.cellButtonPressed(button:)), for: .touchUpInside)
        currentView?.btnBuy.tag = index
        currentView?.btnBuy.addTarget(self, action: #selector(ProductsViewController.buyButtonPressed(button:)), for: .touchUpInside)
        currentView?.btnAddtoCart.tag = index
        currentView?.btnAddtoCart.addTarget(self, action: #selector(ProductsViewController.cartButtonPressed(button:)), for: .touchUpInside)
        return currentView
    }
    
    
  
    
    func buttonClicked(sender:UIButton) {
        
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    func swipeViewDidScroll(_ swipeView: SwipeView!) {
        
        let items = swipeView.visibleItemViews as! [FTSurvivalDetail]
        for view in items {
            let index = swipeView.index(ofItemView: view)
            let frame = view.convert(view.frame, to: swipeView.superview!)
            
            let subtractSize = CGFloat(index) * swipeView.frame.width
            let scrolledX: CGFloat = frame.minX - subtractSize
            
            let normalise = max(-1, min(1, scrolledX / swipeView.frame.size.width))
            view.viewScrollNormalised = normalise
        }
    }
    
    
    
    func swipeViewDidEndDecelerating(_ swipeView: SwipeView!) {
        let items = swipeView.visibleItemViews as! [FTSurvivalDetail]
        for view in items {
            let index = swipeView.index(ofItemView: view)
            self.taPageControl.currentPage = index
        }
        
    }
    
    func buyButtonPressed(button : UIButton){
     let productSelected = productModelArray[button.tag]
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        let VC1 = storyBoard.instantiateViewController(withIdentifier: "OrderViewController") as! OrderViewController
        
        VC1.productToBuy = productSelected
        self.navigationController?.pushViewController(VC1, animated: true)
        
        
    }
    
    func cartButtonPressed(button : UIButton){
        let productSelected = productModelArray[button.tag]
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Cart")
        
        
        
         fetchRequest.predicate = NSPredicate(format: "id == '\(productSelected.id)'")
        do {
            
            let addedproducts = try ad.persistentContainer.viewContext.fetch(fetchRequest) as! [Cart]
            if (addedproducts.count == 0){
                utility.addtocart(id: productSelected.id, image: productSelected.image, quantity: "1", price: productSelected.prize, productname: productSelected.name)
                TWMessageBarManager.sharedInstance().showMessage(withTitle: "ADDED on Cart", description: "This Item is added on cart", type: .success)
                let tabItems = self.tabBarController?.tabBar.items as NSArray!
                
                // In this case we want to modify the badge number of the third tab:
                let tabItem = tabItems?[2] as! UITabBarItem
                
                // Now set the badge of the third tab
                if tabItem.badgeValue != nil{
                    tabItem.badgeValue = "\(Int(tabItem.badgeValue!)!+1)"

                }else{
                    tabItem.badgeValue = "\(1)"
                }
                
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle: "ADD ERROR", description: "You already Have this Item in your cart", type: .error)
            }
        } catch  {
            print("error")
        }
        
        
        
        
    }

    
}

