//
//  SignUpViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/19/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import  TWMessageBarManager

class SignUpViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var signUpView: UIView!

    @IBOutlet weak var txtConfirmPassWord: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var textEmail: UITextField!
    @IBOutlet weak var textFieldName: UITextField!
      
    
    
    @IBOutlet weak var textField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
hideKeyboardWhenTappedAround()
        // Do any additional setup after loading the view.
       /* let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = signupView.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        signupView.addSubview(blurEffectView)*/
        
      //  NotificationCenter.default.addObserver(self, selector: #selector(SignUpViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
       // NotificationCenter.default.addObserver(self, selector: #selector(SignUpViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        self.addDoneButtonOnKeyboard()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func registerAction(_ sender: Any) {
        if (textFieldName.text?.isEmpty)!||(textEmail.text?.isEmpty)!||(txtPassword.text?.isEmpty)!||(txtConfirmPassWord.text?.isEmpty)!||(txtPhone.text?.isEmpty)! || !isValidEmail(testStr: textEmail.text!) || !isEqual(password: txtPassword.text!, confirmPassword: txtConfirmPassWord.text!) || !((txtPhone.text?.isNumeric)!){
            TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please check.There are some inconsistency in the data you provided.", type: .error)
            
        }else{
            let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/shop_reg.php?name=\(textFieldName.text!)&email=\(textEmail.text!)&mobile=\(txtPhone.text!)&password=\(txtPassword.text!)"
            let urlRequest = URL(string: urlString)
            
            URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
                print(response)
                print(error)
                if error == nil{
                    guard let returnData = String(data: data!, encoding: .utf8) else{
                        return
                    }
                    DispatchQueue.main.async {
                        TWMessageBarManager.sharedInstance().showMessage(withTitle:"System Says" , description: returnData, type: .info)
                    }
                    
                    
                }else{
                   TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
                }
                
            }.resume()
        }
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func cancelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

    func isValidEmail(testStr:String) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    func isEqual(password:String,confirmPassword:String) -> Bool {
        if password == confirmPassword{
            return true
        }else{
            
            TWMessageBarManager.sharedInstance().showMessage(withTitle: "Password Mismatch", description: "Please check ur password fields", type: .error)
            return false
            
        }
    }
    
    func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0{
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    
    func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y != 0{
                self.view.frame.origin.y += keyboardSize.height
            }
        }
    }

    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    { print("in here")
        // Try to find next responder
        if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            // Not found, so remove keyboard.
            textField.resignFirstResponder()
        }
        // Do not add a line break
        return false
    }
   
    
    func addDoneButtonOnKeyboard() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 320, height: 50))
        doneToolbar.barStyle       = UIBarStyle.default
        let flexSpace              = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem  = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.done, target: self, action: #selector(SignUpViewController.doneButtonAction))
        
        var items = [UIBarButtonItem]()
        items.append(flexSpace)
        items.append(done)
        
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.txtPhone.inputAccessoryView = doneToolbar
    }
    
    func doneButtonAction() {
        self.txtPhone.resignFirstResponder()
       
    }
    
}
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }
}
