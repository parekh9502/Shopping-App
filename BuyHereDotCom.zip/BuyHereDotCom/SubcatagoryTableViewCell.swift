//
//  SubcatagoryTableViewCell.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/29/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//


import UIKit

class SubcatagoryTableViewCell: UITableViewCell {

    @IBOutlet weak var viewContent: UIView!
    @IBOutlet weak var txtRight: UILabel!
    @IBOutlet weak var txtLeft: UILabel!
    @IBOutlet weak var imageViewLeft: UIImageView!
    @IBOutlet weak var imageViewRight: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
