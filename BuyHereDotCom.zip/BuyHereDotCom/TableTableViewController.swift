//
//  TableTableViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/25/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import  CoreData
import SDWebImage
import UserNotifications
import SimpleAnimation
import CircleMenu

class TableTableViewController: UITableViewController, NSFetchedResultsControllerDelegate {
    var ad = UIApplication.shared.delegate as! AppDelegate
    var frc: NSFetchedResultsController<Catagory>?
    let utility = Utility()
    var webservices = Webservices()
    
    
   
   
    
    @IBAction func signOutAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        UserDefaults.standard.removeObject(forKey: "username")
        UserDefaults.standard.removeObject(forKey: "useremail")
        UserDefaults.standard.removeObject(forKey: "userphone")
        UserDefaults.standard.removeObject(forKey: "signedin")
        
        
        
        let VC1 = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        
        
        self.present(VC1, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        title = "CATAGORY"
        
       
        
        
        
        if (utility.entityIsEmpty(entity: "Catagory")){
            webservices.setProductCatagory { (message) in
                if let msg = message as? String{
                    print(msg)
                    let context = self.ad.persistentContainer.viewContext
                    let fetchrequest = NSFetchRequest<Catagory>(entityName: "Catagory")
                    print("Batch size",fetchrequest.fetchBatchSize)
                    fetchrequest.sortDescriptors = [NSSortDescriptor(key:"catqagoryDescription",ascending:true)]
                    self.frc = NSFetchedResultsController<Catagory>(fetchRequest: fetchrequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
                    self.frc?.delegate = self as! NSFetchedResultsControllerDelegate
                    do {
                        try self.frc?.performFetch()
                    } catch  {
                        fatalError("failed to fetch entities \(error)")
                    }
                   self.tableView.reloadData()
                   
                }
            }
        }else{
            let context = self.ad.persistentContainer.viewContext
            let fetchrequest = NSFetchRequest<Catagory>(entityName: "Catagory")
            
            fetchrequest.sortDescriptors = [NSSortDescriptor(key:"catqagoryDescription",ascending:true)]
            self.frc = NSFetchedResultsController<Catagory>(fetchRequest: fetchrequest, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
            self.frc?.delegate = self as! NSFetchedResultsControllerDelegate
            do {
                try self.frc?.performFetch()
            } catch  {
                fatalError("failed to fetch entities \(error)")
            }
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.backBarButtonItem?.title = ""
        self.navigationItem.leftBarButtonItem = nil;
        let backButton = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        self.navigationItem.backBarButtonItem = backButton;
        setupNavigationWithColor(UIColor.black)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        if utility.entityIsEmpty(entity: "Catagory"){
            return 0
        }else{
             return frc!.sections!.count
        }
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        guard let sections = self.frc?.sections else {
            fatalError("No sections in fetchedResultsController")
        }
        let sectionInfo = sections[section]
        
        return sectionInfo.numberOfObjects

    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       

        // Configure the cell...
        let cell = tableView.dequeueReusableCell(withIdentifier: "catagoryCell", for: indexPath) as! CatagoryTableViewCell
        
        // Configure the cell...
        guard let object = self.frc?.object(at: indexPath) else {
            fatalError("Attempt to configure cell without a managed object")
        }
        
       
        cell.txtCatagoryName.text = object.catagoryName
        cell.txtDescription.text = object.catqagoryDescription
        cell.txtDescription.transform = .identity
        let animationTypeDeciderVal = indexPath.row%3
        switch animationTypeDeciderVal {
        case 0:
            cell.txtDescription.slideIn(from: .right,duration:4.0)
        case 1:
            cell.txtDescription.slideIn(from: .bottom,duration:5.0)
        
        case 2:
            cell.txtDescription.slideIn(from: .top,duration:6.0)
            
        default:
            cell.txtDescription.slideIn(from: .right,duration:5.0)
        }
       // cell.txtDescription.slideIn(from: .right,duration:5.0)
        cell.imageVwCatagory.sd_setImage(with: URL(string:object.catagoryImage!))
        
        do {
            let imageforcatagory = try utility.showImageFromDocumentDirectory(imageName: (object.catagoryImage!).fileName())
            cell.imageVwCatagory.image = imageforcatagory

        } catch  {
            print("Error Reading Image")
        }
        
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let object = self.frc?.object(at: indexPath) else {
            fatalError("Attempt to configure cell without a managed object")
        }
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        let VC1 = storyBoard.instantiateViewController(withIdentifier: "SubCatagoryTableViewController") as! SubCatagoryTableViewController
        
        VC1.catagoryID = object.id
        self.navigationController?.pushViewController(VC1, animated: true)
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>){
        tableView.beginUpdates()
    }
    
    
    /* Notifies the delegate that all section and object changes have been sent. Enables NSFetchedResultsController change tracking.
     Clients may prepare for a batch of updates by using this method to begin an update block for their view.
     Providing an empty implementation will enable change tracking if you do not care about the individual callbacks.
     */
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>){
        tableView.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?){
        switch type {
        case .insert:
            
            tableView.insertRows(at: [newIndexPath!], with: UITableViewRowAnimation.fade)
        
        case .update:
            tableView.reloadData()
        default:
            print("")
        }
    }
    
    
    @IBAction  func triggerNotification(){
        let content = UNMutableNotificationContent()
        content.title = NSString.localizedUserNotificationString(forKey: "Elon said:", arguments: nil)
        content.body = NSString.localizedUserNotificationString(forKey: "Hello Tom！Get up, let's play with Jerry!", arguments: nil)
        content.sound = UNNotificationSound.default()
        content.badge = UIApplication.shared.applicationIconBadgeNumber + 1 as NSNumber;
        content.categoryIdentifier = "com.elonchan.localNotification"
        // Deliver the notification in five seconds.
        let trigger = UNTimeIntervalNotificationTrigger.init(timeInterval: 60.0, repeats: true)
        let request = UNNotificationRequest.init(identifier: "FiveSecond", content: content, trigger: trigger)
        
        // Schedule the notification.
        let center = UNUserNotificationCenter.current()
        center.add(request)
    }
    
    
    @IBAction func stopNotification(_ sender: AnyObject) {
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
    }

    func setupNavigationWithColor(_ color: UIColor) {
        let font = UIFont.boldSystemFont(ofSize: 20);
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName : color, NSFontAttributeName : font as Any]
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
    }
    
 

    
    
}
