//
//  Utility.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/25/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//


import Foundation
import  CoreData
import UIKit

enum OperationError: Error {
    case fileReadError
    case conversionFailedError
}

struct Utility {
    
    var ad = UIApplication.shared.delegate as! AppDelegate

    func entityIsEmpty(entity: String) -> Bool
    {
        let context =  ad.persistentContainer.viewContext
        do{
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
            let count  = try context.count(for: request)
            return count == 0 ? true : false
        }catch{
            return true
        }
        
        
    }
    
    func addtocart(id:String,image: String,quantity:String,price:String,productname:String){
        let product = NSEntityDescription.insertNewObject(forEntityName: "Cart", into: self.ad.persistentContainer.viewContext) as! Cart
    
        product.id = id;
        product.image = image
        product.price = price
        product.productName = productname
        product.quantity = quantity
        
        self.ad.saveContext()
    }
    
    func saveImageDocumentDirectory(imageName: String,imagefromImageVw: UIImage){
        let fileManager = FileManager.default
        let urls = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        
        var UrlinDocuments = urls.first?.appendingPathComponent("image")
        //var isDir : ObjCBool = true
        if !fileManager.fileExists(atPath: (UrlinDocuments?.path)!){
            do {
                
                try FileManager.default.createDirectory(atPath: (UrlinDocuments?.path)!, withIntermediateDirectories: true, attributes: nil)
                print("directory created")
            } catch let error as NSError {
                print("Error creating directory: \(error.localizedDescription)")
            }
        }
        
        
        
        UrlinDocuments = UrlinDocuments?.appendingPathComponent(imageName+".jpg")
        let image = imagefromImageVw
        
        print(UrlinDocuments!)
        let imageData = UIImageJPEGRepresentation(image, 0.5)
        do {
            try imageData?.write(to: UrlinDocuments!)
        } catch {
            print("Error")
        }
        
    }
    
    
    func getDataFromUrl(url: URL, completion: @escaping (_ data: Data?, _  response: URLResponse?, _ error: Error?) -> Void) {
        URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            completion(data, response, error)
            }.resume()
    }
    
    func downloadImage(url: URL) {
        print("Download Started")
        getDataFromUrl(url: url) { (data, response, error)  in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            
                let urlString = "\(url)"
           // print(UIImage(data: data)!)
            if let imagedata = UIImage(data: data) {
                self.saveImageDocumentDirectory(imageName: urlString.fileName(), imagefromImageVw: imagedata)
            }
            
            
            
            
        }
    }
    
    func showImageFromDocumentDirectory(imageName: String) throws -> UIImage{
        let fileManager = FileManager.default
        let urls = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        
        var UrlinDocuments = urls.first?.appendingPathComponent("image")
        UrlinDocuments = UrlinDocuments?.appendingPathComponent(imageName+".jpg")
        print("image read from",UrlinDocuments!)
        
        guard let imagedata = try? Data(contentsOf: UrlinDocuments!) else{
            throw OperationError.conversionFailedError
        }
        
        guard let image = UIImage(data: imagedata) else{
            throw OperationError.conversionFailedError
        }
        
        //imageVw.image = image
        print("this image",UrlinDocuments!)
        return image
        
        
        
    }
}
extension String {
    
    func fileName() -> String {
        
        if let fileNameWithoutExtension = NSURL(fileURLWithPath: self).deletingPathExtension?.lastPathComponent {
            return fileNameWithoutExtension
        } else {
            return ""
        }
    }
    
    func fileExtension() -> String {
        
        if let fileExtension = NSURL(fileURLWithPath: self).pathExtension {
            return fileExtension
        } else {
            return ""
        }
    }
}

extension String {
    var isNumeric: Bool {
        guard self.characters.count > 0 else { return false }
        let nums: Set<Character> = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
        return Set(self.characters).isSubset(of: nums)
    }
    func istenDigit(number:String)-> Bool{
        if number.characters.count == 10{
            return true
        }else{
            return false
        }
    }
}
