//
//  ViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/25/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import RevealingSplashView
import TWMessageBarManager
import  SCLAlertView

class ViewController: UIViewController {

    var webservices = Webservices()
    @IBOutlet weak var txtMobile: UITextField!
   
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var imageViewBG: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let revealingSplashView = RevealingSplashView(iconImage: UIImage(named: "shoppingcart")!,iconInitialSize: CGSize(width: 170, height: 170), backgroundColor: UIColor.white)
        
        //revealingSplashView.useCustomIconColor = true
        //revealingSplashView.iconColor = UIColor.red
        revealingSplashView.duration = 3.0
        revealingSplashView.animationType = SplashAnimationType.woobleAndZoomOut
        
        //Adds the revealing splash view as a sub view
        self.view.addSubview(revealingSplashView)
        
        //Starts animation
        revealingSplashView.startAnimation(){
            print("Completed")
        }

       hideKeyboardWhenTappedAround()
       
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    @IBAction func SignIn(_ sender: Any) {
        //http://rjtmobile.com/ansari/shopingcart/androidapp/shop_login.php?mobile=123456&password=ansari
        
        if (txtMobile.text?.isEmpty)! || (txtPassword.text?.isEmpty)! || !((txtMobile.text?.isNumeric)!){
            SCLAlertView().showInfo("Error", subTitle: "Provide right info to sign in")
        }else{
            webservices.getSignInMsg(number: txtMobile.text!, password: txtPassword.text!, completion: { (signInmsg) in
                guard let msg = signInmsg as? String else{
                    return
                }
                if msg.contains("success"){
                    
                    let userinfo = msg.components(separatedBy: " ")
                    
                    UserDefaults.standard.set(userinfo[1], forKey: "username")
                    UserDefaults.standard.set(userinfo[2], forKey: "useremail")
                    UserDefaults.standard.set(userinfo[3], forKey: "userphone")
                    UserDefaults.standard.set("true", forKey: "signedin")
                    
                    /*let VC1 = self.storyboard!.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                    let navController = UINavigationController(rootViewController: VC1)  // Creating a navigation controller with VC1 at the root of the navigation stack.*/
                    let VC1 = self.storyboard!.instantiateViewController(withIdentifier: "TabViewRoot") as! UITabBarController
                    self.present(VC1, animated:true, completion: nil)
                }else{
                    DispatchQueue.main.async {
                        SCLAlertView().showInfo("Sign In Error", subTitle: msg)
                    }
                  
                }
            })
        }
        
        
    }
    
    @IBAction func forgetPasswordAction(_ sender: UIButton) {
        
        
    }
    
}

