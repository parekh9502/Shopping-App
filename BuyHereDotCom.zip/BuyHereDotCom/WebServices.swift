//
//  WebServices.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/19/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//


import Foundation
import UIKit
import TWMessageBarManager
import CoreData
typealias completionHandler4signIn = (Any) -> ()
typealias completionHandler4resetPassword = (Any) -> ()
typealias completionHandler4ProductCatagory = (Any) -> ()
typealias completionHandler4Order = (Any) -> ()
typealias completionHandler4OrderHistory = (Any) -> ()
typealias completionHandler4OrderTracking = (Any) -> ()


struct ProductCatagory {
    var id: String
    var catagoryName: String
    var catagoryDescription: String
    var catagoryUrl: String
}

class Webservices: NSObject {
    
    static let sharedInstance = Webservices()
    var ad = UIApplication.shared.delegate as! AppDelegate
    let utility = Utility()
    func getSignInMsg(number: String,password: String,completion:@escaping completionHandler4signIn) {
        
        
        var signInMsg:String?
        
            let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/shop_login.php?mobile=\(number)&password=\(password)"
            let urlRequest = URL(string: urlString)
            
            URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
                print(response)
                print(error)
                if error == nil{
                    guard let returnData = String(data: data!, encoding: .utf8) else{
                        return
                    }
                    print(returnData)
                    // TWMessageBarManager.sharedInstance().showMessage(withTitle:"We want you to know" , description: returnData, type: .success)
                    if returnData.contains("success"){
                        do{
                            guard let jsonResult =  try JSONSerialization.jsonObject(with: data!, options:[]) as? [[String:Any]] else{
                                return
                            }
                            
                            let dict = jsonResult.first as? [String:String]
                            
                            signInMsg = (dict?["msg"])!+" "+(dict?["UserName"])!+" "+(dict?["UserEmail"])!+" "+(dict?["UserMobile"])!
                            
                        }catch{
                            print("Error")
                        }
                        
                    }else if returnData.contains("not register"){
                        signInMsg = "mobile number not registered.Please sign up"
                    }else if returnData.contains("incorrect password"){
                        signInMsg = "Your password is incorrect"
                    }
                    
                    completion(signInMsg)
                }else{
                      TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
                }
                
                }.resume()
            
        
        
        
        
    }
    
    
    func orderItem(itemID: String,itemName: String,quantity: String,finalPrice:String,mobileNumber:String,completion:@escaping completionHandler4Order) {
        
        
        var resetMsg:String?
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/orders.php?&item_id=\(itemID)&item_names=\(itemName)&item_quantity=\(quantity)&final_price=\(finalPrice)&mobile=\(mobileNumber)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            print(response)
            print(error)
            if error == nil{
                guard let returnData = String(data: data!, encoding: .utf8) else{
                    return
                }
                if returnData.contains("Confirmed"){
                    resetMsg = "Order Placed \(returnData)"
                }else{
                    resetMsg = "Order cloud not be placed"
                }
                completion(resetMsg)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }
    
    func getPasswordReset(number: String,password: String,newpassword: String,completion:@escaping completionHandler4resetPassword) {
        
        
        var resetMsg:String?
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/shop_reset_pass.php?&mobile=\(number)&password=\(password)&newpassword=\(newpassword)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            print(response)
            print(error)
            if error == nil{
                guard let returnData = String(data: data!, encoding: .utf8) else{
                    return
                }
                if returnData.contains("success"){
                    resetMsg = "Password reset Successful"
                }else{
                    resetMsg = "Password Reset failed"
                }
                completion(resetMsg)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }
    func getOrderTracking(orderID: String,completion:@escaping completionHandler4OrderTracking) {
        
        
        var resetMsg:String?
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/order_track.php?order_id=\(orderID)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            print(response)
            print(error)
            if error == nil{
                guard let returnData = String(data: data!, encoding: .utf8) else{
                    return
                }
                if returnData.contains("1"){
                    resetMsg = "Order Confirm"
                }else if returnData.contains("2"){
                    resetMsg = "Order Dispatched"
                }else if returnData.contains("3"){
                    resetMsg = "Order On the Way"
                }else if returnData.contains("4"){
                    resetMsg = "Order Delivered"
                }else{
                    resetMsg = "Not Found"
                }
                completion(resetMsg)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }
    
    func setProductCatagory(completion:@escaping completionHandler4ProductCatagory) {
        
        
        var msg:String?
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/cust_category.php"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
           
            if error == nil{
                do{
                    guard let jsonResult =  try JSONSerialization.jsonObject(with: data!, options:[]) as? [String:Any] else{
                        return
                    }
                    
                    guard let catagory = jsonResult["Category"] as? [[String:Any]] else{
                        return
                    }
                    for eachcatagory in catagory{
                        let catagoryProduct = NSEntityDescription.insertNewObject(forEntityName: "Catagory", into: self.ad.persistentContainer.viewContext) as! Catagory
                        catagoryProduct.id = eachcatagory["Id"] as? String
                        catagoryProduct.catagoryName = eachcatagory["CatagoryName"] as! String
                        catagoryProduct.catqagoryDescription = eachcatagory["CatagoryDiscription"] as? String
                        catagoryProduct.catagoryImage = eachcatagory["CatagoryImage"] as? String
                       
                        self.ad.saveContext()
                        self.utility.downloadImage(url: URL(string:(eachcatagory["CatagoryImage"] as? String)!)!)
                    }
                    msg = "catagory inserted"
                    
                }catch{
                    print("Error")
                }
                
                completion(msg)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }
    
    func setProductSubCatagory(id: String, completion:@escaping completionHandler4ProductCatagory) {
        
        
        var msg:String?
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/cust_sub_category.php?Id=\(id)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            
            if error == nil{
                do{
                    guard let jsonResult =  try JSONSerialization.jsonObject(with: data!, options:[]) as? [String:Any] else{
                        return
                    }
                    
                    guard let subcatagory = jsonResult["SubCategory"] as? [[String:Any]] else{
                        return
                    }
                    for eachcatagory in subcatagory{
                        let subcatagoryProduct = NSEntityDescription.insertNewObject(forEntityName: "SubCatagory", into: self.ad.persistentContainer.viewContext) as! SubCatagory
                        subcatagoryProduct.id = eachcatagory["Id"] as? String
                        subcatagoryProduct.subCatagoryName = eachcatagory["SubCatagoryName"] as? String
                        subcatagoryProduct.subCatagoryDescription = eachcatagory["SubCatagoryDiscription"] as? String
                        subcatagoryProduct.subCatagoryImage = eachcatagory["CatagoryImage"] as? String
                        
                        self.ad.saveContext()
                        self.utility.downloadImage(url: URL(string:(eachcatagory["CatagoryImage"] as? String)!)!)
                    }
                    msg = "subcatagory inserted"
                    
                }catch{
                    print("Error")
                }
                
                completion(msg)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }

    
    func setProduct(id: String, completion:@escaping completionHandler4ProductCatagory) {
        
        
        var msg:String?
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/cust_product.php?Id=\(id)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            print(response)
            print(error)
            if error == nil{
                do{
                    guard let jsonResult =  try JSONSerialization.jsonObject(with: data!, options:[]) as? [String:Any] else{
                        return
                    }
                    
                    guard let products = jsonResult["Product"] as? [[String:Any]] else{
                        return
                    }
                    for eachproduct in products{
                        let product = NSEntityDescription.insertNewObject(forEntityName: "Product", into: self.ad.persistentContainer.viewContext) as! Product
                        product.id = eachproduct["Id"] as? String
                        product.prize = eachproduct["Prize"] as? String
                        product.productDescription = eachproduct["Discription"] as? String
                        product.productImage = eachproduct["Image"] as? String
                        product.quantity = eachproduct["Quantity"] as? String
                        product.productName = eachproduct["ProductName"] as? String
                        
                        self.ad.saveContext()
                       // print(URL(string:((eachproduct["Image"] as? String)?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!)!)
                        self.utility.downloadImage(url: URL(string:((eachproduct["Image"] as? String)?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!)!)
                    }
                    msg = "product inserted"
                    
                }catch{
                    print("Error")
                }
                
                completion(msg)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }
    
    func getOrderHistory(mobile:String,completion:@escaping completionHandler4OrderHistory) {
        
        var orderHistoryModelArray:[OrderHistory] = []
       
        
        let urlString = "http://rjtmobile.com/ansari/shopingcart/androidapp/order_history.php?&mobile=\(mobile)"
        let urlRequest = URL(string: urlString)
        
        URLSession.shared.dataTask(with: urlRequest!) { (data, response, error) in
            
            if error == nil{
                do{
                    guard let jsonResult =  try JSONSerialization.jsonObject(with: data!, options:[]) as? [String:Any] else{
                        return
                    }
                    
                    guard let orderHistory = jsonResult["Order History"] as? [[String:Any]] else{
                        return
                    }
                    for order in orderHistory{
                        let orderHistoryModel = OrderHistory(id: order["OrderID"] as! String, name: order["ItemName"] as! String, quantity: order["ItemQuantity"] as! String, status: order["OrderStatus"] as! String, price: order["FinalPrice"] as! String)
                        orderHistoryModelArray.append(orderHistoryModel)
                        
                    }
                   
                    
                }catch{
                    print("Error")
                }
                
                completion(orderHistoryModelArray)
            }else{
                TWMessageBarManager.sharedInstance().showMessage(withTitle:"Error" , description: "Error occured.Please try again later", type: .error)
            }
            
            }.resume()
        
    }
    
    
    
}
