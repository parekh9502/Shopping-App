//
//  WelcomeViewController.swift
//  BuyHereDotCom
//
//  Created by Pritesh Parekh on 11/19/16.
//  Copyright © 2016 Pritesh Parekh. All rights reserved.
//

import UIKit
import CircleMenu
import SimpleAnimation
import CoreData
class WelcomeViewController: UIViewController,CircleMenuDelegate {

    
    @IBOutlet weak var txtAvertise: UILabel!
    @IBOutlet weak var imageVwAdvertise: UIImageView!
    @IBOutlet weak var txtWelcome: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let midX = self.view.bounds.midX
        let midY = self.view.bounds.midY
        let button = CircleMenu(
            frame: CGRect(x: midX-50, y: midY-50, width: 50, height: 50),
            normalIcon:"menu-icon-white",
            selectedIcon:"icon_close-1",
            buttonsCount: 4,
            duration: 2,
            distance: 120)
        button.delegate = self
        button.layer.cornerRadius = button.frame.size.width / 2.0
        
        view.addSubview(button)
        // Do any additional setup after loading the view.
        imageVwAdvertise.transform = .identity
        imageVwAdvertise.slideIn(from: .right,duration:6.0)
        txtAvertise.transform = .identity
        txtAvertise.slideIn(from: .top,duration:5.0)
         txtWelcome.text = "Hello \(UserDefaults.standard.string(forKey: "username")!), \nBuyHere.Com is your one stop solution for online shopping"
        txtWelcome.transform = .identity
        txtWelcome.bounceIn()
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
     
    */
    
    func circleMenu(_ circleMenu: CircleMenu, willDisplay button: UIButton, atIndex: Int){
        switch atIndex {
        case 0:
            button.setBackgroundImage(#imageLiteral(resourceName: "logout"), for: .normal)
            button.backgroundColor = UIColor.red
        case 1:
            button.setBackgroundImage(#imageLiteral(resourceName: "lock-xxl"), for: .normal)
            button.backgroundColor = UIColor.green
        case 2:
            button.setBackgroundImage(#imageLiteral(resourceName: "makefg"), for: .normal)
            button.backgroundColor = UIColor.purple
        case 3:
            button.setBackgroundImage(#imageLiteral(resourceName: "Magnifying_glass_icon"), for: .normal)
            button.backgroundColor = UIColor.yellow
        default:
            button.setBackgroundImage(#imageLiteral(resourceName: "Cart-Icon"), for: .normal)
            button.backgroundColor = UIColor.white
        }
    }
    func circleMenu(_ circleMenu: CircleMenu, buttonDidSelected button: UIButton, atIndex: Int){
        switch atIndex {
        case 0:
            
            dismiss(animated: true, completion: nil)
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            UserDefaults.standard.removeObject(forKey: "username")
            UserDefaults.standard.removeObject(forKey: "useremail")
            UserDefaults.standard.removeObject(forKey: "userphone")
            UserDefaults.standard.removeObject(forKey: "signedin")
            deleteAllRecords()
            
            let VC1 = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            
            self.present(VC1, animated: true, completion: nil)
        case 1:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)

            let VC1 = storyBoard.instantiateViewController(withIdentifier: "ResetPasswordViewController") as! ResetPasswordViewController
            self.navigationController?.pushViewController(VC1, animated: true)
        case 2:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            

            let VC1 = storyBoard.instantiateViewController(withIdentifier: "OrderHistoryTableViewController") as! OrderHistoryTableViewController
            self.navigationController?.pushViewController(VC1, animated: true)
        case 3:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)

            let VC1 = storyBoard.instantiateViewController(withIdentifier: "OrderTrackViewController") as! OrderTrackViewController
            self.navigationController?.pushViewController(VC1, animated: true)
        default:
             print("click")
        }
    }
    
    func deleteAllRecords() {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let context = delegate.persistentContainer.viewContext
        
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Cart")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
        } catch {
            print ("There was an error")
        }
    }
}
